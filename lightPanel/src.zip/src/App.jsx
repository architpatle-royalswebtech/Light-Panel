// import React, { useState, useEffect } from 'react';
// import LightPanel from './assets/LightPanel';
// import LightPanel2 from './assets/LightPanel2';
// import LightPanel3 from './assets/LightPanel3';
// import Nav from './assets/nav';

// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// // import "./assets/Wall1"
// import Layout from './assets/Layout';

// const App = () => {


//   return (
//     <Router>

//       <Routes>
//         <Route path="/" element={<Layout />} >
//           <Route path="/hybec1" element={<LightPanel2 pic='/Hybec1.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataH1" />} />
//           <Route path="/wall1" element={<LightPanel pic='/Wall1.jpg' LightData="https://lighpanelbackend.onrender.com/api/data1" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata1" />} />
//           <Route index element={<LightPanel pic="/LightPanel.jpg" LightData="https://lighpanelbackend.onrender.com/api/data" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata" />} />
//           <Route path="/wall3" element={<LightPanel pic="/Wall3.jpg" LightData="https://lighpanelbackend.onrender.com/api/data3" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata3" />} />
//           <Route path="/wall4" element={<LightPanel pic="/Wall4.jpg" LightData="https://lighpanelbackend.onrender.com/api/data4" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata4" />} />
//          <Route path="/gatelight" element={<LightPanel3 pic="/Gatelights.jpg" LightData="https://lighpanelbackend.onrender.com/api/dataGl" bollardData="https://lighpanelbackend.onrender.com/api/dataFl" CellingData="https://lighpanelbackend.onrender.com/api/dataCl" GardenSpikeData="https://lighpanelbackend.onrender.com/api/dataGs" />} />
//           {/* <Route path="/wall4" element={<LightPanel pic="/Wall4.jpg"  LightData="https://lighpanelbackend.onrender.com/api/data"/>} />  
//         <Route path="/wall5" element={<LightPanel pic="/Wall5.jpg"  LightData="https://lighpanelbackend.onrender.com/api/data"/>} /> */}

//           <Route
//             path="/nav2"
//             element={
//               <>
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update" title="Wall Lamps & FootLamp" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb" title="Nirvana Bollards" />
//               </>
//             }
//           />
//           <Route
//             path="/nav"
//             element={
//               <>
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data1" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update1" title="Wall Lamps & FootLamp" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata1" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb1" title="K Lite Bollards" />
//               </>
//             }
//           />
//           <Route
//             path="/nav3"
//             element={
//               <>
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data3" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update3" title="Wall / Lamp Flood Light & FootLamp" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata3" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb3" title="Nirvana Bollards (Floor)" />
//               </>
//             }
//           />
//           <Route
//             path="/nav4"
//             element={
//               <>
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data4" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId4/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update4" title="Wall / Lamp Flood Light & FootLamp" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata4" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId4/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb4" title="Nirvana Bollards (Floor)" />
//               </>
//             }
//           />

//           <Route
//             path="/navHybec1"
//             element={
//               <>
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataH1" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdH1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateH1" title="Hybec 1" />
//               </>
//             }
//           />

// <Route
//             path="/Gatelightnav"
//             element={
//               <>
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataGl" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdGl/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateGl" title="GateLight" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataFl" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdFl/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFl" title="FootLamp/ Wall Light" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataCl" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdCl/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateCl" title="Ceiling Light" />
//                 <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataGs" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdGs/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateGs" title="Garden Spike" />

//               </>
//             }
//           />
//         </Route>

//       </Routes>

//     </Router>


//   );
// };

// export default App;
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LightPanel from './assets/LightPanel';
import LightPanel2 from './assets/LightPanel2';
import LightPanel3 from './assets/LightPanel3';
import LightPanel4 from './assets/LightPanel4';
import Nav from './assets/nav';
import Layout from './assets/Layout';
import AdminLogin from './assets/AdminLogin';
import LogOut from './assets/LogOut';
import CartsPage from "./assets/CartsPage"; 
import LightPanelWithCart from "./assets/LightPanelWithCart";
import LoginForm from './assets/LoginForm';
import OTPVerification from './assets/OTPVerification';

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(
    localStorage.getItem("isAuthenticated") === "true"
  );
  const [showLogin, setShowLogin] = useState(true);
  const [showOTP, setShowOTP] = useState(false);
  const [email, setEmail] = useState('');

  useEffect(() => {
    localStorage.setItem("isAuthenticated", isAuthenticated);
  }, [isAuthenticated]);

  const handleLogin = async (loginData) => {
    try {
      // First, send login request to get OTP
      const response = await fetch("https://lighpanelbackend.onrender.com/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(loginData),
      });

      if (response.ok) {
        const data = await response.json();
        setEmail(loginData.email);
        setShowLogin(false);
        setShowOTP(true);
      } else {
        console.error("Login failed");
        // Handle error (show message to user)
      }
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  const handleOTPVerification = async (otp) => {
    try {
      const response = await fetch("https://lighpanelbackend.onrender.com/api/auth/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, otp }),
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem("authToken", data.token);
        setIsAuthenticated(true);
        setShowOTP(false);
      } else {
        console.error("OTP verification failed");
        // Handle error (show message to user)
      }
    } catch (error) {
      console.error("OTP verification error:", error);
    }
  };

  const handleResendOTP = async () => {
    try {
      const response = await fetch("https://lighpanelbackend.onrender.com/api/auth/resend-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        console.log("OTP resent successfully");
      } else {
        console.error("Failed to resend OTP");
      }
    } catch (error) {
      console.error("Resend OTP error:", error);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
          {showLogin ? (
            <LoginForm onLogin={handleLogin} />
          ) : (
            <OTPVerification 
              onVerify={handleOTPVerification} 
              onResend={handleResendOTP} 
              email={email}
            />
          )}
        </div>
      </div>
    );
  }


  return (<>
      (<>

        <Router>
                  <LogOut setIsAuthenticated={setIsAuthenticated} />

          <>

            <Routes>

              <Route path="/" element={<Layout />}>
                <Route path="/login" element={<AdminLogin onLogin={() => setIsAuthenticated(true)} />
                } />
                <Route path="/hanging1" element={<LightPanelWithCart pic='/Hanging1.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataHanging1" />} />

                 <Route path="/Astberg" element={<LightPanelWithCart pic='/Astberg.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataAstberg" />} />


            
                <Route path="/hanging2" element={<LightPanelWithCart pic='/Hanging2.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataHanging2" />} />

                <Route path="/hybec1" element={<LightPanelWithCart pic='/Hybec1.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataH1" />} />
                <Route path="/hybec2" element={<LightPanelWithCart pic='/Hybec2.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataH2" />} />

                <Route path="/nirvana1" element={<LightPanelWithCart pic='/Nirvana1.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataNirvana1" />} />
                <Route path="/nirvana2" element={<LightPanelWithCart pic='/Nirvana2.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataNirvana2" />} />

                <Route path="/philips" element={<LightPanelWithCart pic='/Philips.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataPhilips" />} />

                <Route path="/SC1" element={<LightPanelWithCart pic='/SurfaceCOB.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataSC1" bollardData="https://lighpanelbackend.onrender.com/api/bollarddataSC2" />} />

                <Route path="/exhaustfan1" element={<LightPanelWithCart pic='/ExhaustFans.jpg' LightData="https://lighpanelbackend.onrender.com/api/dataExhaustFan1" bollardData="https://lighpanelbackend.onrender.com/api/bollarddataExhaustFan2" CellingData="https://lighpanelbackend.onrender.com/api/dataExhaustFan3" />} />


                <Route path="/wall1" element={<LightPanelWithCart wallName="Wall1" pic='/Wall1.jpg' LightData="https://lighpanelbackend.onrender.com/api/data1" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata1" CellingData="https://lighpanelbackend.onrender.com/api/Footlampdata1"  />} />
                <Route index element={<LightPanel3 pic="/LightPanel.jpg" LightData="https://lighpanelbackend.onrender.com/api/data" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata" CellingData="https://lighpanelbackend.onrender.com/api/Footlampdata2" />} />
                <Route path="/wall3" element={<LightPanelWithCart wallName="Wall3" pic="/Wall3.jpg" LightData="https://lighpanelbackend.onrender.com/api/data3" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata3" CellingData="https://lighpanelbackend.onrender.com/api/Footlampdata3"  />} />
                <Route path="/wall4" element={<LightPanelWithCart wallName="Wall4" pic="/Wall4.jpg" LightData="https://lighpanelbackend.onrender.com/api/data4" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata4" CellingData="https://lighpanelbackend.onrender.com/api/Footlampdata4" />} />  

                <Route path="/wall5" element={<LightPanelWithCart wallName="Wall5" pic="/Wall5.jpg" LightData="https://lighpanelbackend.onrender.com/api/data5" bollardData="https://lighpanelbackend.onrender.com/api/bollarddata5" />} />
                
                <Route path="/carts" element={<CartsPage />} />  {/* ✅ Newly added */}
              
                <Route path="/Fan1" element={<LightPanelWithCart pic="/Fan1.jpg" LightData="https://lighpanelbackend.onrender.com/api/dataF1" bollardData="https://lighpanelbackend.onrender.com/api/bollarddataFl1" CellingData="https://lighpanelbackend.onrender.com/api/dataF1T" />} />
                <Route path="/Fan2" element={<LightPanelWithCart pic="/Fan2.jpg" LightData="https://lighpanelbackend.onrender.com/api/dataF2" bollardData="https://lighpanelbackend.onrender.com/api/bollarddataFl2" CellingData="https://lighpanelbackend.onrender.com/api/dataF2T" />} />
                <Route path="/Geyser2" element={<LightPanelWithCart pic="/Geysers2.jpg" LightData="https://lighpanelbackend.onrender.com/api/dataG2" bollardData="https://lighpanelbackend.onrender.com/api/bollarddataG2Filter" CellingData="https://lighpanelbackend.onrender.com/api/dataG2Fan" />} />

                <Route path="/Fan3" element={<LightPanelWithCart pic="/Fan3.jpg" LightData="https://lighpanelbackend.onrender.com/api/dataF3" bollardData="https://lighpanelbackend.onrender.com/api/bollarddataFl3" />} />

                <Route path="/gatelight" element={<LightPanelWithCart pic="/Gatelights.jpg" LightData="https://lighpanelbackend.onrender.com/api/dataGl" bollardData="https://lighpanelbackend.onrender.com/api/dataFl" CellingData="https://lighpanelbackend.onrender.com/api/dataCl" GardenSpikeData="https://lighpanelbackend.onrender.com/api/dataGs" />} />

                {/* tables */}

              </Route>



            </Routes>
          </>

        </Router>
      </>

      ) : (<>

        <Router>
          <LogOut setIsAuthenticated={setIsAuthenticated} />

          <Routes>

            <Route path="/" element={<Layout />}>

              <Route
                path="/navSC1"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataSC1" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdSC1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateSC1" title="SurfaceCOB 1" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddataSC2" searchUrl={"https://lighpanelbackend.onrender.com/api/getbIdSC2/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateSC2" title="SurfaceCOB 2" />
                  </>
                }
              />

              <Route
                path="/nav2"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update" title="Wall Lamps" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb" title="Nirvana Bollards" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/Footlampdata2" searchUrl={"https://lighpanelbackend.onrender.com/api/getFootlampId2/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFootlamp2" title="FootLamp" />

                  </>
                }
              />

              <Route
                path="/nav"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data1" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update1" title="Wall Lamps" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata1" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb1" title="K Lite Bollards" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/Footlampdata1" searchUrl={"https://lighpanelbackend.onrender.com/api/getFootlampId1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFootlamp1" title="FootLamp" />

                  </>
                }
              />

              <Route
                path="/nav3"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data3" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update3" title="Wall / Lamp Flood Light & FootLamp" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata3" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb3" title="Nirvana Bollards (Floor)" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/Footlampdata3" searchUrl={"https://lighpanelbackend.onrender.com/api/getFootlampId3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFootlamp3" title="FootLamp" />

                  </>
                }
              />

              <Route
                path="/nav4"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data4" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId4/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update4" title="Wall / Lamp Flood Light & FootLamp" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata4" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId4/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb4" title="Bollards (Floor)" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/Footlampdata4" searchUrl={"https://lighpanelbackend.onrender.com/api/getFootlampId4/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFootlamp4" title="FootLamp" />

                  </>
                }
              />

              <Route
                path="/nav5"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/data5" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightId5/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/update5" title="Wall / Lamp Flood Light & FootLamp" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddata5" searchUrl={"https://lighpanelbackend.onrender.com/api/getbId5/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateb5" title="Nirvana Bollards (Floor)" />
                  </>
                }
              />


              <Route
                path="/navFan3"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataF3" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdF3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateF3" title="Fan3 " />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddataFl3" searchUrl={"https://lighpanelbackend.onrender.com/api/getbIdFl3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFl3" title="Light" />
                  </>
                }
              />


              <Route path="/navHybec1" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataH1" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdH1/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateH1" title="Hybec 1" />} />
              <Route path="/navHybec2" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataH2" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdH2/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateH2" title="Hybec 2" />} />

              <Route path="/navNirvana1" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataNirvana1" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdNirvana1/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateNirvana1" title="Nirvana 1" />} />
              <Route path="/navNirvana2" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataNirvana2" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdNirvana2/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateNirvana2" title="Nirvana 2" />} />

              <Route path="/navPhilips" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataPhilips" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdPhilips/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updatePhilips" title="Philips" />} />

              <Route path="/Gatelightnav" element={
                <>
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataGl" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdGl/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateGl" title="GateLight" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataFl" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdFl/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFl" title="FootLamp/ Wall Light" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataCl" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdCl/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateCl" title="Ceiling Light" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataGs" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdGs/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateGs" title="Garden Spike" />
                </>

              } />
              <Route path="/navFan1" element={
                <>
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataF1" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdF1/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateF1" title="Fan1" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddataFl1" searchUrl="https://lighpanelbackend.onrender.com/api/getbIdFl1/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFl1" title="Light" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataF1T" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdF1T/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateF1T" title="Fan1 light 2" />
                </>
              } />

              <Route path="/navGeysers1" element={
                <>
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataG2" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdG2/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateG2" title="Geyser" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddataG2Filter" searchUrl="https://lighpanelbackend.onrender.com/api/getbIdG2Filter/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateG2Filter" title="Filter" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataG2Fan" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdG2Fan/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateG2Fan" title="Fan" />
                </>
              } />
              <Route path="/navFan2" element={
                <>
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataF2" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdF2/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateF2" title="Fan2" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddataFl2" searchUrl="https://lighpanelbackend.onrender.com/api/getbIdFl2/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateFl2" title="Light" />
                  <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataF2T" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdF2T/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateF2T" title="Fan2 light 2" />
                </>
              } />
              <Route path="/navHanging1" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataHanging1" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdHanging1/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateHanging1" title="Hanging 1" />} />

              <Route path="/navAstberg"element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataAstberg"searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdAstberg/"UpdateUrl="https://lighpanelbackend.onrender.com/api/updateAstberg"title="Astberg"/>}/>


              <Route path="/navHanging2" element={<Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataHanging2" searchUrl="https://lighpanelbackend.onrender.com/api/getLightIdHanging2/" UpdateUrl="https://lighpanelbackend.onrender.com/api/updateHanging2" title="Hanging 2" />} />
              <Route
                path="/navExhaustFan1"
                element={
                  <>
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataExhaustFan1" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdExhaustFan1/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateExhaustFan1" title="Exhaust Fan 1" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/bollarddataExhaustFan2" searchUrl={"https://lighpanelbackend.onrender.com/api/getbIdExhaustFan2/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateExhaustFan2" title="Exhaust Fan 1" />
                    <Nav apiUrl="https://lighpanelbackend.onrender.com/api/dataExhaustFan3" searchUrl={"https://lighpanelbackend.onrender.com/api/getLightIdExhaustFan3/"} UpdateUrl="https://lighpanelbackend.onrender.com/api/updateExhaustFan3" title="Wallfan" />

                  </>
                }
              />
            </Route>
          </Routes>
        </Router>
      </>)
  </>
  );
};

export default App;
