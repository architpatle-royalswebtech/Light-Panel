import React, { useState } from "react";

function AdminOtpLogin({ onLogin }) {
  const [step, setStep] = useState("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();
    const res = await fetch("https://yourbackend.com/api/auth/adminotplogin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (res.ok) {
      setEmail(data.email);
      setStep("otp");
    } else {
      alert(data.message);
    }
  };

  const handleOtpVerify = async (e) => {
    e.preventDefault();
    const res = await fetch("https://yourbackend.com/api/auth/verify-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, otp }),
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem("token", data.token);
      onLogin();
    } else {
      alert("Invalid OTP");
    }
  };

  return (
    <div>
      {step === "login" ? (
        <form onSubmit={handleLogin}>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
          <button type="submit">Login</button>
        </form>
      ) : (
        <form onSubmit={handleOtpVerify}>
          <p>OTP sent to: {email}</p>
          <input
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="Enter OTP"
          />
          <button type="submit">Verify OTP</button>
        </form>
      )}
    </div>
  );
}

export default AdminOtpLogin;
