import React from 'react';
import { useNavigate } from "react-router-dom";

const LogOut = ({ setIsAuthenticated, }) => {
  const navigate = useNavigate();
  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem("isAuthenticated");
    navigate('/');
  };

  return (
    <div className='relative '>
      <button className='text-white bg-red-700 p-2 rounded-md hover:bg-red-800 absolute top-6 lg:right-3 right-0' onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default LogOut;
