// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import "./LightPanel.css";
// import Button from "../assets/Editbtn";
// const LightPanel = () => {
//   const [lights, setLights] = useState([]); // Store API data
//   const [hoveredLight, setHoveredLight] = useState(null);
//   const [Bollards, setbollard] = useState([]);
 
//   useEffect(() => {
//     const fetchLights = async () => {
//       try {
//         const response = await axios.get("https://lighpanelbackend.onrender.com/api/data");
//         setLights(response.data.data); // Store API data in state
//       } catch (error) {
//         console.error("Error fetching light data:", error);
//       }
//     };

//     fetchLights();
//   }, []);


//   useEffect(() => {
//     const fetchLights = async () => {
//       try {
//         const response = await axios.get("https://lighpanelbackend.onrender.com/api/bollarddata");
//         setbollard(response.data.data); // Store API data in state
//       } catch (error) {
//         console.error("Error fetching light data:", error);
//       }
//     };

//     fetchLights();
//   }, []);
  
//   return (
//     <div className="mainDiv flex flex-col gap-8" >
//       <div
//         style={{
//           position: "relative",
//           backgroundImage: "url('/LightPanel.jpg')",
//           backgroundSize: "contain",
//           backgroundPosition: "center center",
//           backgroundRepeat: "no-repeat",
//           width: "1200px",
//           height: "600px",
//           msOverflowX: "scroll"
//         }}
//       >
//         {/* Lights from API */}
//         {lights.map((light) => (
//           <div
//             key={light._id || light.Model}
//             style={{
//               position: "absolute",
//               top: light.y,
//               left: light.x,
//               cursor: "pointer",
//             }}
//             onClick={() => setHoveredLight(light)}
//             onMouseLeave={() => setHoveredLight(null)}
//           >
//             <div className="lightDiv"
//               style={{
//                 // visibility: "hidden",
//                 width: "30px",
//                 height: "30px",
//                 backgroundColor: "yellow",
//                 // borderRadius: "50%",
//                 border: "2px solid black",
//               }}
//             ></div>
//           </div>
//         ))}

//         {/* Bollards */}
//         {Bollards.map((bollard, index) => (
//           <div
//             key={bollard._id}
//             style={{
//               position: "absolute",
//               top: bollard.y,
//               left: bollard.x,
//               cursor: "pointer",
//             }}
//             onClick={() => setHoveredLight(bollard)}
//             onMouseLeave={() => setHoveredLight(null)}
//           >
//             <div
//               style={{
//                 visibility: "hidden",

//                 width: "18px",
//                 height: "119px",
//                 backgroundColor: "yellow",
//                 borderRadius: "50%",
//                 border: "2px solid black",
//               }}
//             ></div>
//           </div>
//         ))}

//         {/* Tooltip for Hovered Light or Bollard */}
//         {hoveredLight && (
//           <div
//             className="absolute z-10 w-[200px] bg-gray-900/90 text-white p-4 rounded-lg shadow-xl"

//             style={{

//               top: hoveredLight.y,
//               left: hoveredLight.x,
//               transform: "translate(-50%, -120%)",

//               padding: "15px",
//               borderRadius: "8px",
//               textAlign: "center",
//               boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.2)",
//               zIndex: 10,
//               width: "200px",
//               fontFamily: "'Arial', sans-serif",
//             }}
//           >
//             {hoveredLight?.Model ? (
//               <h4 style={{ fontSize: "16px", fontWeight: "bold", marginBottom: "8px" }}>
//                 {`Model: ${hoveredLight.Model}`}
//               </h4>
//             ) : (
//               <p>data not available</p>
//             )}

//             {hoveredLight.MRP !== 0 && (
//               <p style={{ fontSize: "14px", margin: "4px 0" }}>
//                 {(hoveredLight.MRP && `MRP: ₹${hoveredLight.MRP}`)}
//               </p>
//             )}
//             {hoveredLight.ListPrice && (<p style={{ fontSize: "14px", margin: "4px 0" }}>
//               {`List Price: ₹${hoveredLight.ListPrice}`}
//             </p>)}
//             {hoveredLight.Dimensions && (<p style={{ fontSize: "14px", margin: "4px 0" }}>
//               {hoveredLight.Dimensions ? `Dimensions: ${hoveredLight.Dimensions}` : "Dimensions not available"}
//             </p>)}
//           </div>
//         )}
//       </div>
//       <Button />
      
//     </div>

//   );

// };

// export default LightPanel;





// here data came from db

import React, { useEffect, useState } from "react";
import axios from "axios";
import "./LightPanel.css";
import Button from "../assets/Editbtn";
import LoaderLight from "../assets/loader";
// import CartDisplay from "./cartDisplay";
import { Link } from "react-router-dom";



const LightPanel = ({ wallName, pic, LightData, bollardData }) => {
  const [lights, setLights] = useState([]);
  const [hoveredLight, setHoveredLight] = useState(null);
  const [bollards, setBollards] = useState([]);
  const [visibleLights, setVisibleLights] = useState({});
  const [visibleBollards, setVisibleBollards] = useState({});
  const [Loader, setLoader] = useState(true);
  const [cartItems, setCartItems] = useState([]);
  const [carts, setCarts] = useState({});
const [selectedCart, setSelectedCart] = useState(null); // current selected cart name

  // const [qty, setQty] = useState(1); // Quantity logic commented out

  useEffect(() => {
    const fetchLights = async () => {
      try {
        const response = await axios.get(LightData);
        setLights(response.data.data);
        console.log(response.data.data);
      } catch (error) {
        console.error("Error fetching light data:", error);
      } finally {
        setTimeout(() => {
          setLoader(false);
        }, 3000);
      }
    };

    fetchLights();
  }, [LightData]);
  useEffect(() => {
    const fetchAllCartsFromBackend = async () => {
      try {
        const response = await axios.get("https://lighpanelbackend.onrender.com/api/allcarts");
        const cartList = response.data.carts;
  
        const structuredCarts = {};
        cartList.forEach((cart) => {
          structuredCarts[cart.cartName] = cart.items;
        });
  
        setCarts(structuredCarts);
      } catch (error) {
        console.error("Error loading carts from backend:", error);
      }
    };
  
    fetchAllCartsFromBackend();
  }, []);
  

  useEffect(() => {
    const fetchBollards = async () => {
      try {
        const response = await axios.get(bollardData);
        setBollards(response.data.data);
      } catch (error) {
        console.error("Error fetching bollard data:", error);
      }
    };
    fetchBollards();
  }, [bollardData]);

  const handleLightClick = (light) => {
    setHoveredLight((prev) => (prev === light ? null : light));
    setVisibleLights((prev) => ({
      [light._id]: !prev[light._id],
    }));
  };

  const handleBollardClick = (bollard) => {
    setHoveredLight((prev) => (prev === bollard ? null : bollard));
    setVisibleBollards((prev) => ({
      [bollard._id]: !prev[bollard._id],
    }));
  };
  const updateQty = (model, delta) => {
    setCarts((prevCarts) => {
      const updatedItems = prevCarts[selectedCart].map((item) => {
        if (item.Model === model) {
          const newQty = Math.max(1, (item.qty || 1) + delta);
          return { ...item, qty: newQty };
        }
        return item;
      });
  
      return {
        ...prevCarts,
        [selectedCart]: updatedItems,
      };
    });
  };

  const handleAddToCart = async (item) => {
    if (!selectedCart) {
      const choice = window.prompt("Type 'new' to create a new cart or 'use' to use an existing one:");
      if (choice === "new") {
        const cartName = window.prompt("Enter a new cart name:");
        if (!cartName) return;
      
        if (carts[cartName]) {
          alert("A cart with this name already exists. Please use a different name.");
          return;
        }
      
        const newCartItems = [{ ...item, qty: 1 }];
      
        setCarts((prev) => ({
          ...prev,
          [cartName]: newCartItems,
        }));
        setSelectedCart(cartName);
      
        try {
          await axios.post("https://lighpanelbackend.onrender.com/api/carts", {
            cartName,
            items: newCartItems,
          });
          alert("Cart created and saved!");
        } catch (err) {
          console.error("Failed to save new cart:", err);
          alert("Error saving cart to backend.");
        }
      
        return;
      }
      
       else if (choice === "use") {
        const name = window.prompt("Enter the existing cart name to load from backend:");
        if (!name) return;
  
        try {
          await axios.get(`https://lighpanelbackend.onrender.com/api/cart/${cartName}`);
          

alert(`Cart "${name}" .`);

  
          alert(`Cart '${carts.cartName}' loaded successfully.`);
        } catch (err) {
          console.error("Error fetching cart:", err);
          alert("Cart not found or could not be loaded.");
        }
      } else {
        return;
      }
    }
  
    if (selectedCart) {
      const isDuplicate = carts[selectedCart]?.some((i) => i.Model === item.Model);
      if (!isDuplicate) {
        setCarts((prev) => ({
          ...prev,
          [selectedCart]: [...(prev[selectedCart] || []), { ...item, qty: 1 }],
        }));
      } else {
        alert("Item already exists in the selected cart.");
      }
    }
  };
  
  
  

  return (
    <>
      {Loader ? (
        <LoaderLight />
      ) : (
        <div className="mainDiv flex flex-col gap-8 mr-auto ml-auto">
          <div
            style={{
              position: "relative",
              backgroundImage: `url(${pic})`,
              backgroundSize: "contain",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
              width: "1200px",
              height: "600px",
              borderRadius: "10px",
            }}
          >
            {lights.map((light) => (
              <div
                key={light._id || light.Model}
                style={{
                  position: "absolute",
                  top: light.y,
                  left: light.x,
                  cursor: "pointer",
                }}
                onClick={() => handleLightClick(light)}
              >
                <div
                  className="lightDiv"
                  style={{
                    width: light.width || "30px",
                    height: light.height || "30px",
                    backgroundColor: "grey",
                    opacity: 0.4,
                    visibility: visibleLights[light._id] ? "visible" : "hidden",
                  }}
                ></div>
              </div>
            ))}

            {bollards.map((bollard) => (
              <div
                key={bollard._id}
                style={{
                  position: "absolute",
                  top: bollard.y,
                  left: bollard.x,
                  cursor: "pointer",
                }}
                onClick={() => handleBollardClick(bollard)}
              >
                <div
                  style={{
                    width: bollard.width || "18px",
                    height: bollard.height || "119px",
                    backgroundColor: "grey",
                    opacity: 0.5,
                    visibility: visibleBollards[bollard._id]
                      ? "visible"
                      : "hidden",
                  }}
                ></div>
              </div>
            ))}

            {hoveredLight && (
              <div
                className="absolute z-10 w-[200px] bg-gray-900/90 text-white p-4 rounded-lg shadow-xl"
                style={{
                  top: hoveredLight.y,
                  left: hoveredLight.x,
                  transform: "translate(-50%, -120%)",
                  padding: "15px",
                  borderRadius: "8px",
                  textAlign: "center",
                  boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.2)",
                  zIndex: 10,
                  width: "200px",
                  fontFamily: "'Arial', sans-serif",
                }}
              >
                {hoveredLight?.Model ? (
                  <h4
                    style={{
                      fontSize: "16px",
                      fontWeight: "bold",
                      marginBottom: "8px",
                    }}
                  >
                    {`Model: ${hoveredLight.Model}`}
                  </h4>
                ) : (
                  <p>Data not available</p>
                )}

                {hoveredLight.ListPrice && (
                  <p style={{ fontSize: "14px", margin: "4px 0" }}>
                    {`List Price: ₹${hoveredLight.ListPrice}`}
                  </p>
                )}
                {hoveredLight.Dimensions && (
                  <p style={{ fontSize: "14px", margin: "4px 0" }}>
                    {`Dimensions: ${hoveredLight.Dimensions}`}
                  </p>
                )}

                {/* Quantity Selector - Commented Out */}
                {/*
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    backgroundColor: "#f2f2f2",
                    padding: "6px 10px",
                    borderRadius: "20px",
                    marginTop: "12px",
                  }}
                >
                  <button onClick={() => setQty((prev) => Math.max(1, prev - 1))}>-</button>
                  <span>{qty}</span>
                  <button onClick={() => setQty((prev) => prev + 1)}>+</button>
                </div>
                */}

<div style={{ marginTop: "12px", display: "flex", gap: "10px", justifyContent: "center" }}>
  {/* Add to Cart Button */}
  <button
    onClick={() => handleAddToCart(hoveredLight)}
    style={{
      backgroundColor: "#00cc66",
      color: "#fff",
      padding: "8px 16px",
      border: "none",
      borderRadius: "20px",
      fontSize: "14px",
      fontWeight: "bold",
      cursor: "pointer",
    }}
  >
     ADD
  </button>

  {/* Remove from Cart Button */}
  <button
    onClick={() => {
      if (selectedCart && carts[selectedCart]) {
        const updated = carts[selectedCart].filter(
          (i) => i.Model !== hoveredLight.Model
        );
        setCarts((prev) => ({
          ...prev,
          [selectedCart]: updated,
        }));
      }
    }}
    style={{
      backgroundColor: "#cc3300",
      color: "#fff",
      padding: "8px 16px",
      border: "none",
      borderRadius: "20px",
      fontSize: "14px",
      fontWeight: "bold",
      cursor: "pointer",
    }}
  >
    Remove
  </button>
</div>

              </div>
            )}
          </div>
          <div style={{ display: "flex",justifyContent:"center", gap:"23px", marginTop: "16px", width:"50vw"}}>
  <button
    onClick={() => {
      const cartNames = Object.keys(carts);
      if (cartNames.length === 0) {
        alert("No carts available.");
        return;
      }

      const selected = window.prompt(
        `Available carts:\n${cartNames.join(", ")}\n\nType the cart name you want to use:`
      );

      if (!selected || !carts[selected]) {
        alert("Invalid cart name.");
        return;
      }

      setSelectedCart(selected);
    }}
    style={{
      backgroundColor: "#3b82f6",
      color: "white",
      padding: "10px 20px",
      fontSize: "16px",
      border: "none",
      borderRadius: "8px",
      cursor: "pointer",
      fontWeight: "bold",
   
    
    }}
  >
    Show Carts
  </button>

  <Link
    to="/carts"
    style={{
      backgroundColor: "#1d4ed8",
      color: "white",
      padding: "10px 20px",
      fontSize: "16px",
      borderRadius: "8px",
      textDecoration: "none",
      fontWeight: "bold",
      display: "inline-block",
    }}
  >
    View All Saved Carts
  </Link>

</div>
 
<div style={{ display: "flex", gap: "32px", alignItems: "flex-start" }}>
  {/* <CartDisplay cartItems={cartItems} /> */}

  {selectedCart && (
    <div
      style={{
        position: "absolute",
        top: "100px",
        right: "50px",
        width: "420px",
        backgroundColor: "#ffffff",
        border: "1px solid #e5e7eb",
        borderRadius: "12px",
        padding: "20px",
        boxShadow: "0 10px 15px rgba(0,0,0,0.1)",
        zIndex: 20,
      }}
    >
     <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "12px" }}>
  <h3 style={{ fontSize: "20px", fontWeight: "bold", color: "#111827" }}>
    Cart: {selectedCart}
  </h3>
  <div style={{ display: "flex", gap: "8px" }}>
    <button
      onClick={() => {
        const cartNames = Object.keys(carts);
        if (cartNames.length === 0) {
          alert("No existing carts.");
          return;
        }

        const selected = window.prompt(
          `Available carts:\n${cartNames.join(", ")}\n\nType the name of the cart you want to switch to:`
        );

        if (!selected || !carts[selected]) {
          alert("Invalid cart name.");
          return;
        }

        setSelectedCart(selected);
      }}
      style={{
        backgroundColor: "#3b82f6",
        color: "#fff",
        padding: "6px 12px",
        fontSize: "14px",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
      }}
    >
      Change Cart
    </button>

    <button
      onClick={() => {
        const cartName = window.prompt("Enter a new cart name:");
        if (!cartName) return;

        if (carts[cartName]) {
          alert("A cart with this name already exists.");
          return;
        }

        setCarts((prev) => ({
          ...prev,
          [cartName]: [],
        }));
        setSelectedCart(cartName);
      }}
      style={{
        backgroundColor: "#10b981",
        color: "#fff",
        padding: "6px 12px",
        fontSize: "14px",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
      }}
    >
      Add New Cart
    </button>
  </div>
</div>


      <table style={{ width: "100%", marginTop: "16px", borderCollapse: "collapse" }}>
        <thead>
        <tr style={{ backgroundColor: "#f3f4f6", textAlign: "left" }}>
    <th style={{ padding: "10px", borderBottom: "1px solid #e5e7eb" }}>Model</th>
    <th style={{ padding: "10px", borderBottom: "1px solid #e5e7eb" }}>Price</th>
    <th style={{ padding: "10px", borderBottom: "1px solid #e5e7eb" }}>Dimensions</th>
    <th style={{ padding: "10px", borderBottom: "1px solid #e5e7eb" }}>Qty</th>
  </tr>
        </thead>
        <tbody>
  {carts[selectedCart]?.map((item, index) => (
<tr
  key={index}
  style={{ borderBottom: "1px solid #e5e7eb", cursor: "pointer" }}
  onClick={() => setHoveredLight(item)}
>      <td style={{ padding: "10px" }}>{item.Model}</td>
      <td style={{ padding: "10px" }}>₹{item.ListPrice}</td>
      <td style={{ padding: "10px" }}>{item.Dimensions}</td>
      <td style={{ padding: "10px" }}>
    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
    <button
      onClick={() => updateQty(item.Model, -1)}
      style={{
        padding: "4px 8px",
        backgroundColor: "#d1d5db",
        border: "none",
        borderRadius: "4px",
        cursor: "pointer",
      }}
    >
      -
    </button>
    <span>{item.qty || 1}</span>
    <button
      onClick={() => updateQty(item.Model, 1)}
      style={{
        padding: "4px 8px",
        backgroundColor: "#d1d5db",
        border: "none",
        borderRadius: "4px",
        cursor: "pointer",
      }}
    >
      +
    </button>
  </div>
</td>
    </tr>
  ))}
</tbody>
      </table>
      {/* ✅ Save Button After Table */}
      <button
  onClick={async () => {
    if (!selectedCart || !carts[selectedCart] || carts[selectedCart].length === 0) {
      alert("Cart is empty or not selected.");
      return;
    }

    // const wallName = window.prompt("Enter wall name for this cart:");
    // if (!wallName) return;

    try {
      const response = await axios.post("https://lighpanelbackend.onrender.com/api/carts", {
        cartName: selectedCart,
        // wallName,
        items: carts[selectedCart],
      });

      alert("Cart saved successfully!");
      console.log("Saved cart:", response.data);
    } catch (error) {
      console.error("Error saving cart:", error);
      alert("Failed to save cart.");
    }
  }}
  style={{
    marginTop: "16px",
    backgroundColor: "#22c55e",
    color: "#fff",
    padding: "8px 16px",
    fontSize: "14px",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: "bold",
  }}
>
  Save Cart
</button>
    </div>
  )}
  </div> 
    </div>
      )}
    </>
  );
};

export default LightPanel;












// here data came from json file


// import React, {  useState } from "react";

// import "./LightPanel.css";
// import Button from "../assets/Editbtn";
// import Bollards from "./BollardsWall4.json"
// import Light from "./LightWall4.json"
// const LightPanel = ({pic ="./Wall4.jpg"}) => {
//   const [lights, setLights] = useState(Light);
//   const [hoveredLight, setHoveredLight] = useState(null);
//   const [bollards, setBollards] = useState(Bollards);
//   const [visibleLights, setVisibleLights] = useState({}); // Track visibility of lights
//   const [visibleBollards, setVisibleBollards] = useState({}); // Track visibility of bollards


// //     const fetchLights = async () => {
// //       try {
// //         const response = await axios.get("https://lighpanelbackend.onrender.com/api/data");
// //         setLights(response.data.data);
// //       } catch (error) {
// //         console.error("Error fetching light data:", error);
// //       }
// //     };
// //     fetchLights();
// //   }, []);
// // // setBollards(Bollards)
// //   useEffect(() => {
// //     const fetchBollards = async () => {
// //       try {
// //         const response = await axios.get("https://lighpanelbackend.onrender.com/api/bollarddata");
// //         setBollards(response.data.data);
// //       } catch (error) {
// //         console.error("Error fetching bollard data:", error);
// //       }
// //     };
// //     fetchBollards();
// //   }, []);

//   // Toggle visibility & tooltip on click
//   const handleLightClick = (light) => {
//     setHoveredLight((prev) => (prev === light ? null : light)); // Toggle tooltip
//     setVisibleLights((prev) => ({
      
//       [light.id]: !prev[light.id], // Toggle visibility of clicked light
//     })
//   );
//   };

//   const handleBollardClick = (bollard) => {
//     setHoveredLight((prev) => (prev === bollard ? null : bollard)); // Toggle tooltip
//     // setVisibleBollards((prev) => ({
     
//     //   [bollard.id]: !prev[bollard.id], // Toggle visibility of clicked bollard
//     // }));
//   };
// // console.log(pic);

//   return (
//   <>
//   {/* <Top /> */}
//     <div className="mainDiv flex flex-col gap-8">
//       <div
//         style={{
//           position: "relative",
//           backgroundImage: `url(${pic})`,
//           backgroundSize: "contain",
//           backgroundPosition: "center",
//           backgroundRepeat: "no-repeat",
//           width: "1200px",
//           height: "600px",
//         }}
//       >
//         {/* Lights */}
//         {lights.map((light) => (
//           <div
//             key={light._id || light.id}
//             style={{
//               position: "absolute",
//               top: light.y,
//               left: light.x,
//               cursor: "pointer",
//             }}
//             onClick={() => handleLightClick(light)}
//             // onMouseLeave={() => setHoveredLight(null)}
//           >
//             <div
//               className="lightDiv"
//               style={{
//                 width: light.width|| "30px",
//                 height: light.height || "30px",
//                 backgroundColor: "grey",
//                 opacity: 0.4,
//                 // border: "2px solid black",
//                 // visibility: visibleLights[light.id] ? "visible" : "hidden",
//                 visibility:"visible"
//               }}
//             ></div>
//           </div>
//         ))}

//         {/* Bollards */}
//         {bollards.map((bollard) => (
//           <div
//             key={bollard._id || bollard.id}
//             style={{
//               position: "absolute",
//               top: bollard.y,
//               left: bollard.x,
//               cursor: "pointer",
//             }}
//             onClick={() => handleBollardClick(bollard)}
//           >
//             <div
//               style={{
//                 width: bollard.width || "18px",
//                 height: bollard.height || "119px",
//                 backgroundColor: "grey",
//                 opacity: 0.5,
//                 // borderRadius: "50%",
//                 // border: "2px solid black",
//                 // visibility: visibleBollards[bollard.id] ? "visible" : "hidden",
//                 visibility:"visible"
//               }}
//             ></div>
//           </div>
//         ))}

//         {/* Tooltip for Clicked Light or Bollard */}
//         {hoveredLight && (
//           <div
//             className="absolute z-10 w-[200px] bg-gray-900/90 text-white p-4 rounded-lg shadow-xl"
//             style={{
//               top: hoveredLight.y,
//               left: hoveredLight.x,
//               transform: "translate(-50%, -120%)",
//               padding: "15px",
//               borderRadius: "8px",
//               textAlign: "center",
//               boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.2)",
//               zIndex: 10,
//               width: "200px",
//               fontFamily: "'Arial', sans-serif",
//             }}
//           >
//             {hoveredLight?.Model ? (
//               <h4 style={{ fontSize: "16px", fontWeight: "bold", marginBottom: "8px" }}>
//                 {`Model: ${hoveredLight.Model}`}
//               </h4>
//             ) : (
//               <p>Data not available</p>
//             )}
//             {hoveredLight.MRP !== 0 && (
//               <p style={{ fontSize: "14px", margin: "4px 0" }}>
//                 {(hoveredLight.MRP && `MRP: ₹${hoveredLight.MRP}`)}
//               </p>
//             )}
//             {hoveredLight.ListPrice && (
//               <p style={{ fontSize: "14px", margin: "4px 0" }}>
//                 {`List Price: ₹${hoveredLight.ListPrice}`}
//               </p>
//             )}
//             {hoveredLight.Dimensions && (
//               <p style={{ fontSize: "14px", margin: "4px 0" }}>
//                 {`Dimensions: ${hoveredLight.Dimensions}`}
//               </p>
//             )}
// {/* <button
//       style={{
//         backgroundColor: "#4CAF50", 
//         color: "white",
//         padding: "4px 10px",
//         fontSize: "16px",
//         border: "none",
//         borderRadius: "5px",
//         cursor: "pointer",
//         boxShadow: "4px 4px 10px rgba(0, 0, 0, 0.2)", 
//         transition: "all 0.2s ease-in-out",
//       }}
//       onMouseDown={(e) => {
//         e.target.style.transform = "translateY(2px)";
//         e.target.style.boxShadow = "2px 2px 5px rgba(0, 0, 0, 0.2)";
//       }}
//       onMouseUp={(e) => {
//         e.target.style.transform = "translateY(0)";
//         e.target.style.boxShadow = "4px 4px 10px rgba(0, 0, 0, 0.2)";
//       }}
//     >
//       Edit
//     </button> */}         </div> 
          
//         )}
//       </div>
//       <Button />
//     </div></>
//   );
// };

// export default LightPanel;
